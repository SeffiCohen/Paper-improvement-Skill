# Workflow Reference

## Overview

Run paper improvement as a staged process, not a single pass of stylistic edits.

## Mode Selection

1. `draft_critique`
- Inputs: paper PDF or source.
- Output: diagnosis, risks, and revision priorities.

2. `deep_revision`
- Inputs: paper source, target sections, optional venue.
- Output: exact rewrites and a structured revision plan.

3. `review_response`
- Inputs: reviews, meta-review, draft.
- Output: reviewer-response matrix and manuscript changes.

4. `empirical_integrity`
- Inputs: result tables, run CSVs, code metadata, baseline configs.
- Output: repro status, statistics summary, claim-evidence alignment, experiment queue.

5. `venue_targeting`
- Inputs: target venue or journal.
- Output: venue-specific checklist and compliance fixes.

Combine modes whenever the user supplies multiple input types.

## Recommended Order

1. `SPEC_READY`
- `paper_spec.json` exists.
- Main claims are extracted.
- Paper type, stage, and sections are recorded.

2. `QUALITY_GATE_READY`
- `paper_quality_gate.py` has produced blocker and major issues.
- The top acceptance-risk items are visible.

3. `REVISION_PLAN_READY`
- `make_revision_plan.py` has converted the gate into a prioritized task queue.
- Rewrites are sequenced so narrative fixes and evidence fixes do not conflict.

4. `CLAIM_ALIGNMENT_READY`
- Main claims have anchors.
- Unsupported or overstated claims are narrowed or repaired.

5. `EMPIRICAL_READY` (when applicable)
- `repro_gate.py` is not blocked.
- `analyze_results.py` has summarized multi-seed evidence.
- Baseline, ablation, and robustness gaps are known.

6. `VENUE_READY`
- Current official venue or journal requirements have been checked.
- Desk-reject risks and checklist gaps are resolved.

7. `SUBMISSION_READY`
- Abstract, introduction, related work, methods, results, limitations, and conclusion are aligned.
- Reviewer-response language matches actual manuscript changes.
- Availability, licensing, ethics, and disclosure statements are present if required.

## Triage Rules

### Blockers
Use this severity when the issue can directly invalidate acceptance or desk review.
Examples:
- missing abstract or introduction
- no extractable main claims
- empirical paper missing methods or results sections
- claims broader than visible evidence
- missing essential experimental details for central results
- clear venue noncompliance

### Major Issues
Use when the paper may still be reviewable but is materially weaker.
Examples:
- weak baselines
- no limitations section
- missing related-work positioning
- no path to reproduce results
- no data or code availability explanation

### Moderate Issues
Use when the paper is mostly coherent but leaves avoidable reviewer objections.
Examples:
- captions not self-contained
- unclear notation
- missing practical-significance discussion
- incomplete licensing or artifact notes

### Polish
Use for language tightening, redundancy removal, and local cleanup.

## Output Discipline

- Critique first, then prescribe.
- When revising, show exact replacement text.
- For empirical papers, never separate narrative fixes from evidence fixes.
- For reviewer responses, maintain one-to-one traceability from comment to action.
- For venue-specific guidance, prefer current official sources over memory.
