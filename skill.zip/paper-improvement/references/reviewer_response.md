# Reviewer Response Playbook

## Goal

Turn every reviewer point into one action and one response. Keep the response package traceable, factual, and calm.

## Workflow

1. Normalize each reviewer point.
- Extract the concern, the requested change, and the underlying risk.

2. Classify the point.
- contribution or novelty
- related work
- methods or assumptions
- experiment or baseline gap
- statistics or uncertainty
- reproducibility or artifacts
- clarity or writing
- limitations, ethics, or disclosure

3. Choose the response pattern.
- **Agree and fix**: the reviewer is right and you can change the manuscript.
- **Agree partially**: the reviewer is directionally right but the exact request is too broad.
- **Clarify misunderstanding**: the paper already addresses the point but not clearly enough.
- **Respectfully decline**: the requested change is outside scope, infeasible, or inappropriate for the paper.

4. State the manuscript change.
- Say exactly what changed or will change.
- Point to the destination section, table, figure, or appendix.
- If no change was made, say why and tighten the claim if needed.

5. Keep one-to-one traceability.
- One response row per reviewer point.
- Do not merge unrelated complaints into a vague paragraph.

## Tone Rules

- Start with brief gratitude, not flattery.
- Answer the substance quickly.
- Avoid defensiveness and rhetorical combat.
- Admit valid weaknesses plainly.
- Never promise experiments or analysis that the paper will not actually contain.

## Default Response Block

```text
R1.2 [theme]
Concern:
Response:
Change in manuscript:
Location:
Evidence added or clarified:
Status:
```

## Common Failure Modes

- saying "we agree" but not describing a real change
- claiming a new experiment without specifying where it appears
- answering a clarity complaint with only a defensive explanation
- broadening the claim further while trying to defend it
- writing one global response that loses point-by-point accountability
