# Manuscript Rubric

Use this rubric to prioritize work. Score each dimension from 1 to 5 only when a score is useful; otherwise use the categories qualitatively.

## Blocker Conditions

Treat any of these as blocker-level issues:
- the main claim is unsupported, exaggerated, or contradicted by the visible evidence
- the manuscript lacks a usable abstract, introduction, or central methods/results path
- the paper cannot be understood without hidden assumptions or omitted setup details
- the paper violates a likely venue requirement that can trigger desk rejection
- ethical, approval, or availability requirements appear central and are missing

## Empirical AI/ML or Empirical Computer Science

Recommended weighting:
- problem framing and contribution: 20
- technical soundness and methods: 20
- evidence quality and evaluation: 20
- related work and novelty positioning: 15
- clarity and organization: 10
- limitations, ethics, and scope calibration: 10
- reproducibility and artifacts: 5

Pressure-test these questions:
- is the problem statement specific and important?
- are the contribution claims narrower than or equal to the evidence?
- are the strongest adjacent baselines represented fairly?
- are uncertainty, robustness, and failure cases discussed?
- is there a credible reproduction path?

## Theory Papers

Shift weight away from experiments and toward assumptions, theorem statements, proof completeness, intuition, and positioning.

Pressure-test these questions:
- are assumptions explicit and realistic?
- do theorem statements match the informal narrative?
- are proof sketches and intuitions sufficient in the main paper?
- are boundary conditions or negative results stated honestly?

## Systems Papers

Weight clarity of system claims, experimental realism, deployment conditions, cost measurements, and artifact quality more heavily.

Pressure-test these questions:
- are workloads realistic and comparable?
- are cost and performance trade-offs explicit?
- are system constraints and failure modes visible?
- can another team reproduce the core evaluation?

## Survey, Review, or Systematic Review Papers

Weight coverage, organization, selection logic, taxonomy quality, and synthesis over new experiments.

Pressure-test these questions:
- is the coverage boundary explicit?
- is the inclusion and exclusion logic described?
- does the paper synthesize rather than merely list prior work?
- is the survey taxonomy useful and defensible?

## Rebuttal or Response Packages

Weight traceability, honesty, scope control, and evidence responsiveness.

Pressure-test these questions:
- does every reviewer point receive a direct answer?
- are claimed manuscript changes real and locatable?
- are concessions clear where the reviewer is right?
- are promises proportionate to what will actually be delivered?

## Severity Mapping

- `blocker`: likely to change acceptance outcome or desk-review status
- `major`: likely to trigger substantive reviewer concern
- `moderate`: weakens confidence or clarity but is fixable without changing the paper's core
- `polish`: local presentation improvement only
