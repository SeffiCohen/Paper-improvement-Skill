# Venue Guidance

Venue requirements change frequently. Do not rely on memory for any live conference or journal rule.

## For every venue-specific request

Browse the official venue or journal sources and record:
- submission date and time zone
- main-paper page limits
- supplement or appendix rules
- anonymity policy
- checklist or reproducibility statement requirements
- artifact, code, or data submission options
- review criteria or scoring dimensions
- camera-ready obligations if relevant

## What to verify specifically

### ML and AI conference style workflows
Check for:
- required paper checklist or responsible research form
- reproducibility statement guidance
- anonymity and supplementary-material rules
- whether appendices count toward page limits
- whether code or artifacts can be submitted and how

### Computational or systems artifact workflows
Check for:
- artifact badging or evaluation tracks
- expectations for reusable artifacts, scripts, and archived outputs
- repository or DOI requirements

### Journal workflows
Check for:
- data availability statement requirements
- code availability expectations
- reporting summaries or methods reporting requirements
- ethics, preregistration, or protocol requirements when relevant

## Recommended output for venue checks

Capture the result as:
- venue
- checked source
- date checked
- relevant rule
- implication for the current paper

Always use absolute dates, not relative phrases like "next week" or "tomorrow".
