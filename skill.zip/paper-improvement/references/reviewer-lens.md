# Reviewer Lens

Use this file to simulate how reviewers are likely to judge the paper.

## Soundness

Check:
- are the central claims explicit
- is the methodology appropriate for the question being asked
- are experiments, analyses, or proofs sufficient for the strongest claims
- are baselines fair and current enough
- are evaluation details complete enough to reproduce the conclusions

Common failure modes:
- claims stronger than the evidence
- weak or mismatched baselines
- no ablations for multi-component methods
- no uncertainty, seeds, or error analysis
- selective reporting or missing implementation details

## Presentation and clarity

Check:
- can a reviewer summarize the problem, gap, method, and result after one read
- does each section have a distinct job
- do tables and figures answer specific questions
- are contributions stated once, clearly, and consistently

Common failure modes:
- abstract is generic or all-motivation
- introduction mixes motivation, related work, and contributions without a clean arc
- method section describes operations without assumptions or design rationale
- results section lists numbers without interpretation

## Significance

Check:
- is the paper solving a problem that matters to the field
- do the gains or insights matter beyond one narrow benchmark
- does the work change what researchers should believe or do

Common failure modes:
- technically correct but too incremental for the venue
- no explanation of why the result matters
- gains are too small or fragile to support a strong contribution claim

## Originality

Check:
- is the closest prior work identified
- is the difference precise rather than rhetorical
- is the claimed contribution methodological, empirical, dataset-related, theoretical, or analytic

Common failure modes:
- novelty is described with adjectives instead of contrasts
- related work omits the most dangerous comparison points
- the paper overstates independence from prior methods

## Reproducibility

Check:
- are datasets, splits, metrics, and preprocessing stated
- are seeds, uncertainty, and environment assumptions reported
- is there a code, artifact, or availability plan
- do appendix and supplement carry the details needed to reproduce the paper

Common failure modes:
- hidden preprocessing or unclear split policy
- missing code or availability statement
- only point estimates reported
- incomplete details for tuning, early stopping, or selection

## Responsible research and limitations

Check:
- are limitations explicit and specific
- are risks, biases, misuse, or external validity concerns addressed when relevant
- are failure cases acknowledged

Common failure modes:
- generic one-sentence limitations paragraph
- no discussion of dataset bias or deployment caveats
- ethical language that is disconnected from the actual method or data

## How to use the lens

When critiquing the paper:
1. write 1-2 sentences on each dimension
2. name the highest-risk weakness for that dimension
3. propose the smallest change that would materially improve the score
4. distinguish what can be fixed by writing from what requires new evidence

## Typical high-value reviewer questions

- What is the single strongest piece of evidence for the headline claim?
- Which closest baseline or prior method would most threaten the conclusion if included?
- What exact part of the method is new, and what evidence isolates its contribution?
- How robust is the result to seeds, splits, or tuning choices?
- What limitation would a skeptical reader notice first?
