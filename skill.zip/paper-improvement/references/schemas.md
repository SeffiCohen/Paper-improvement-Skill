# Schemas Reference

## paper_spec.json

### metadata
- `title`: string
- `paper_path`: string
- `paper_id`: string
- `arxiv_id`: string
- `doi`: string
- `code_url`: string
- `target_venue`: string
- `paper_type`: string
- `study_design`: string
- `stage`: string
- `keywords`: array[string]

### extraction
- `method_summary`: string
- `contributions`: array[string]
- `datasets`: array[string]
- `metrics`: array[string]
- `baselines`: array[string]
- `claims`: array[claim]
- `training`: object
- `evaluation`: object

### claim
- `id`: string
- `claim_text`: string
- `metric`: string
- `dataset`: string
- `reported_value`: number|string
- `anchor`: string
- `risk_note`: string (optional)

### manuscript
- `sections`: array[string] or object of section-name -> boolean
- `availability`: object
- `review_context`: object

### manuscript.availability
Suggested fields:
- `data`
- `code`
- `license`
- `artifacts`
- `limitations`
- `ethics`
- `broader_impacts`
- `conflicts`
- `funding`

### manuscript.review_context
Suggested fields:
- `review_comments_path`: string
- `review_comment_count`: integer

### unresolved_fields
- `array[string]`

### lineage
- `generated_at`: ISO datetime
- `generator`: string

## quality_gate.json

- `paper_type_inferred`: string
- `empirical`: boolean
- `readiness`: enum `not_ready|major_revision|revise|polish`
- `scores`: object of category -> numeric score
- `issue_counts`: object
- `issues`: array[issue]
- `recommended_modes`: array[string]
- `generated_at`: ISO datetime

### issue
- `severity`: enum `blocker|major|moderate|info`
- `category`: enum `contribution_scope|structure_clarity|evidence_alignment|empirical_rigor|reproducibility|ethics_reporting`
- `code`: string
- `message`: string
- `recommended_action`: string

## revision_plan.jsonl

One JSON object per line:
- `id`: string
- `severity`: string
- `category`: string
- `title`: string
- `rationale`: string
- `recommended_action`: string
- `effort`: enum `s|m|l`
- `expected_impact`: enum `low|medium|high`
- `owner`: string

## evidence.json

Array of evidence rows used by `claim_evidence_matrix.py`:
- `claim_id`: string
- `source_type`: string such as `table|figure|experiment|theorem|appendix|reviewer_response`
- `location`: string
- `summary`: string
- `supports`: boolean or null
- `strength`: string such as `strong|partial|weak|contradicts`
- `risk_note`: string

## claim_evidence.csv

Suggested columns:
- `claim_id`
- `claim_text`
- `anchor`
- `status`
- `evidence_count`
- `missing_fields`
- `risk_notes`

## review_comments.json

Array of reviewer comments:
- `reviewer`: string
- `comment_id`: string
- `comment`: string
- `theme`: string (optional)
- `severity`: string (optional)
- `planned_action`: string (optional)
- `manuscript_location`: string (optional)
- `response_status`: string (optional)
- `evidence_needed`: string (optional)

## response_matrix.csv

Suggested columns:
- `reviewer`
- `comment_id`
- `theme`
- `severity`
- `comment_summary`
- `planned_action`
- `manuscript_location`
- `response_status`
- `evidence_needed`
- `draft_response`

## runs/results.csv

Required columns:
- `method`
- `dataset`
- `metric`
- `seed`
- `value`

Optional columns:
- `run_id`
- `compute_hours`
