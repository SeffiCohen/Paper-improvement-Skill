# Statistics Reference

## Defaults

- Use multi-seed runs for claim-facing comparisons whenever possible.
- Prefer paired comparisons on shared seeds and shared splits.
- Report uncertainty around both per-method estimates and method deltas.
- Distinguish statistical significance from practical significance.

## Minimum Reporting Block

For each claim-facing empirical result include:
- method
- dataset
- metric
- sample or seed count
- mean
- uncertainty interval
- exact comparison target
- config reference and git SHA when available

## Confidence Intervals

Recommended defaults:
- bootstrap samples: 2000
- confidence level: 95%
- random seed: fixed and logged

Use intervals for both absolute performance and deltas.

## Metric Direction

Some metrics are lower-is-better.
Declare this explicitly instead of letting readers infer it.
Common examples include error rate, WER, CER, perplexity, NLL, RMSE, and latency.

## Method Comparisons

When shared seeds exist, compute paired deltas.
Recommended outputs:
- raw mean delta
- oriented mean delta after accounting for metric direction
- confidence interval on the delta
- shared-seed count
- p-value from a declared test
- whether the candidate appears better under the declared direction

## Multiple Comparisons

When testing many candidates against one baseline, control family-wise error.
Holm correction is a sensible default for a small to moderate number of comparisons.

## Practical Guidance

- Do not claim a win from a single favorable seed.
- Do not compare methods with mismatched tuning budgets without saying so.
- Do not hide negative or fragile ablations if they change the scope of the contribution.
- Do not rely on p-values alone; include effect size and uncertainty.
- If computation prevents full uncertainty reporting, say that plainly and narrow the claim.
