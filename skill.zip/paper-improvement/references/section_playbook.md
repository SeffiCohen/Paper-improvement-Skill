# Section Playbook

## Title
- State the actual object of contribution.
- Avoid inflated words such as "general", "universal", or "state-of-the-art" unless the paper really proves them.
- Keep the scope no broader than the evidence.

## Abstract
- Include problem, method, evidence, and the real take-away.
- Mention setting or data when central to interpreting the result.
- If the result has limits, signal them.
- Never let the abstract claim more than the paper can defend.

## Introduction
- Explain the problem and the specific gap.
- State contributions explicitly and separately.
- Explain why the evidence is credible, not only why the topic is important.
- Make sure the introduction's promises match the experiments or proofs that actually appear later.

## Related Work
- Compare against the strongest directly adjacent work.
- Explain novelty as a boundary, not a slogan.
- Separate "different problem" from "same problem, weaker method".
- Use recent work when it changes the paper's novelty story.

## Methods or Approach
- State assumptions, objectives, and definitions clearly.
- Include the implementation, optimization, or data pipeline details needed to interpret the results.
- Call out any hidden choices that could change results.
- For theory-heavy work, keep proof intuition visible in the main paper even if full proofs move to the appendix.

## Experiments and Results
- Use fair baselines and matched budgets.
- Define metrics and aggregation policies.
- Report uncertainty, not only point estimates.
- Show robustness, not only the best-case run.
- Explain negative results or failure cases when they inform scope.

## Figures and Tables
- Make captions self-contained.
- Include units, sample sizes, and baseline labels where relevant.
- Make axis labels and abbreviations legible without hunting through the text.
- Use tables to verify claims, not merely to decorate the narrative.

## Limitations, Ethics, and Broader Impacts
- State what the method does not establish.
- Describe boundary conditions and likely failure modes.
- For human, sensitive, or deployment-facing work, discuss risks and mitigation plainly.
- Do not hide limitations in hedged language.

## Conclusion
- Re-state what was actually shown.
- Avoid new claims or stronger generalization than the evidence supports.
- End with the most defensible take-away.
