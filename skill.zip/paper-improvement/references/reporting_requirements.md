# Reporting Requirements and Venue Adaptation

Policies change. When a venue or journal is named, fetch the current official source before giving venue-specific advice.

## General Rule

1. Fetch the official author instructions, review form, checklist, call for papers, or editorial policy.
2. Extract only the currently relevant constraints: formatting, anonymity, checklist requirements, artifact expectations, ethics or disclosure rules, and data or code availability rules.
3. Map the manuscript gaps to those current requirements.
4. If the paper spans multiple domains, obey both the venue rules and the study-type reporting guidance.

## Common Patterns

### AI and ML venues
Check for:
- claims aligned to evidence
- limitations and scope calibration
- reproducibility path
- experimental details and baselines
- ethics, broader impacts, and asset licensing when relevant
- human-subjects details when relevant

### Computing venues with artifacts
Check for:
- documented artifacts
- complete or well-scoped rerun instructions
- exercisable scripts or commands
- versioning, environment, and dependency notes
- clear mapping from artifact to headline paper claims

### Nature-style and high-transparency journals
Check for:
- data availability statement
- code and materials availability statement
- clear access conditions for the minimum dataset or materials required to interpret and verify the paper
- protocol or analysis-plan availability when relevant

### Biomedical or clinical journals
Check for:
- current journal instructions
- ICMJE-style manuscript and disclosure expectations when relevant
- the correct study-type reporting guideline

### Health research or study-type-specific domains
Use a current reporting-guideline source such as EQUATOR to identify the right checklist for the study design.
Common examples include randomized trials, observational studies, systematic reviews, diagnostic studies, prognostic studies, qualitative studies, case reports, and economic evaluations.

## Safe Behavior

- Do not hardcode outdated venue rules when the current rule can be fetched.
- Do not assume a reporting checklist is optional if the official current source treats it as mandatory.
- If the venue is unknown, give general best-practice advice and label venue-specific items as pending.
