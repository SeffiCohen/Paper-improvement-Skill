---
name: paper-improvement
description: improve academic papers, especially ai/ml and empirical computer science manuscripts, from rough draft through rebuttal and camera-ready. use when chatgpt must critique a paper pdf, latex, markdown, tables, results csvs, or reviewer comments; strengthen title, abstract, introduction, related work, methods, experiments, results, discussion, limitations, ethics, figures, tables, and artifact sections; test whether claims are supported by evidence; refresh recent related work or current venue requirements; or produce exact rewrites, prioritized revision plans, reviewer-response matrices, claim-evidence tables, and reproducibility packages.
---

# Paper Improvement

Treat paper improvement as a combined writing, evidence, and submission-readiness problem.

## Choose one or more modes

1. **Draft critique mode**
- Use when the user wants a deep review of a draft, PDF, or source manuscript.
- Diagnose contribution, novelty, evidence quality, writing quality, and acceptance risk.

2. **Revision mode**
- Use when the user wants exact rewrites, section restructuring, or a concrete revision plan.
- Produce replacement text, not just generic advice.

3. **Review-response mode**
- Use when reviewer comments, meta-reviews, or rebuttal notes are available.
- Build a point-by-point response plan and connect every response to a manuscript change.

4. **Empirical integrity mode**
- Use when the paper has experiments, result tables, baselines, ablations, code, or run CSVs.
- Pressure-test claims, statistics, reproducibility, and artifact quality before the paper narrative is finalized.

5. **Venue-compliance mode**
- Use when a venue or journal is named.
- Fetch the current official instructions, checklist, review form, or call for papers before giving venue-specific advice.

## Non-negotiable rules

- Ground every major criticism in visible manuscript evidence, explicit missing evidence, or structured run results.
- Never invent citations, experiments, metrics, reviewer comments, venue policies, approvals, or availability statements.
- Prefer exact rewrites, section outlines, figure/table edits, and experiment proposals over vague feedback.
- Separate blockers, major improvements, and polish.
- Keep claims calibrated to the evidence and to the actual scope of the paper.
- Preserve the author's notation, terminology, and technical intent unless there is a strong reason to change them.
- If a venue or journal is named, use the web tool to fetch the current official requirements before giving venue-specific advice.
- If the study is clinical, health, observational, qualitative, systematic-review, or otherwise study-type-specific, use the web tool to identify the relevant current reporting guideline before giving domain-specific advice.
- If source text is available, edit directly in that source language or format. If only a PDF is available, critique from the PDF and provide clean replacement text blocks.
- When critical context is missing, proceed with a best-effort improvement pass and clearly label assumptions instead of stalling.

## Default workflow

1. Intake and mode selection.
- Identify paper type: empirical, theory, systems, survey, review, rebuttal, camera-ready, or mixed.
- Identify stage: outline, draft, submission, revision, rebuttal, or camera-ready.
- Identify inputs available: paper PDF or source, reviewer comments, results tables, code or artifacts, target venue, and compute budget.
- Decide whether the job is primarily narrative, empirical, reviewer-response, or some combination.

2. Build a structured paper spec.
- Run `scripts/build_paper_spec.py` for a machine-readable paper record.
- Add claims, sections, venue, paper type, stage, and availability metadata.
- Use `--merge-json` when structured details are easier to prepare in JSON than on the command line.
- Do not start expensive experiments until the paper spec captures the main claims and unresolved fields.

3. Run a manuscript quality gate.
- Run `scripts/paper_quality_gate.py` on the paper spec.
- Treat `blocker` issues as acceptance-risk items.
- Use the gate to separate missing sections, unsupported claims, reporting gaps, reproducibility gaps, and ethics or scope gaps.
- Run `scripts/make_revision_plan.py` on the quality-gate output to convert issues into a prioritized task queue.

4. Align claims with evidence.
- Build or update a claim list with anchors to tables, figures, theorems, appendices, or experiments.
- Run `scripts/claim_evidence_matrix.py` when a structured claim-evidence table is helpful.
- Rewrite or narrow any claim that is unsupported, partially supported, or broader than the evidence.
- For the abstract and introduction, make sure the headline claims match the strongest verified evidence.

5. Pressure-test empirical rigor when applicable.
- For empirical papers, use `scripts/repro_gate.py` to check reproducibility-critical fields.
- Use `scripts/analyze_results.py` on run CSVs before claiming gains.
- Use `scripts/propose_improvements.py` to queue experiments only after the paper spec and repro gate are in good shape.
- Treat missing uncertainty, weak baselines, seed fragility, or evaluation mismatches as paper issues, not mere engineering issues.

6. Refresh literature and venue expectations.
- For literature refresh, prefer the web tool for current, official, or venue-specific information.
- Use `scripts/lit_refresh.py` when a lightweight ranked starter list from arXiv and Crossref is useful.
- When a venue is specified, fetch the current official checklist or review criteria and adapt the revision plan to it.
- When the paper belongs to a regulated or study-type-specific domain, fetch the current official reporting guidance before offering compliance advice.

7. Produce concrete deliverables.
- Default deliverables are: a concise diagnosis, a prioritized revision plan, exact rewrites for the highest-value sections, a claim-evidence table, and a submission-readiness checklist.
- If reviewer comments are provided, run `scripts/review_response_matrix.py` and return a point-by-point response plan plus revised text.
- If the user asks for a full improvement pass, cover abstract, introduction, related work, methods, results, limitations, and conclusion—not just style edits.

## Output expectations

For a full paper-improvement pass, use this structure unless the user asked for something else:

1. `snapshot`
- Summarize the paper's contribution, the current strength of the draft, and the biggest acceptance risks in three to six sentences.

2. `top blockers`
- Include only issues that could materially change the review outcome.

3. `high-leverage revisions`
- Order changes by expected impact on acceptance probability, clarity, or technical credibility.

4. `exact rewrites`
- Provide replacement text for the title, abstract, introduction, related work framing, results framing, limitations, or response letter as needed.

5. `claim-evidence alignment`
- State which claims are strong, weak, missing support, or overstated.

6. `empirical and reporting risks`
- Cover statistics, baselines, ablations, reproducibility, ethics, availability, and licensing gaps.

7. `submission-ready checklist`
- State what must be true before submission or resubmission.

## Section-specific rules

- **Title**: precise, scoped, and not hypey.
- **Abstract**: problem, method, main evidence, scope limits, and the real take-away in one compact block.
- **Introduction**: state the problem, the gap, the contribution, why it matters, and why the evidence is credible.
- **Related work**: compare against the strongest adjacent work, not only weak or outdated baselines.
- **Methods**: state assumptions, settings, the data pipeline, and decisions needed for replication.
- **Experiments and results**: include strong baselines, uncertainty, practical significance, and failure cases.
- **Figures and tables**: prefer self-contained captions, units, sample sizes, metric definitions, and explicit baseline labels.
- **Limitations and ethics**: state boundary conditions, failure modes, data constraints, risks, and deployment caveats honestly.
- **Conclusion**: summarize what is actually established, not the aspirational story.

## Reviewer-response rules

- Use one response row per reviewer point.
- Thank the reviewer briefly, answer the substance directly, state the manuscript change, and point to where the change will appear.
- Admit valid weaknesses plainly.
- Do not claim to have added experiments, citations, data, or analyses unless they are actually present or explicitly planned.
- When a request cannot be fully satisfied, explain the constraint and tighten the claim.

## Command recipes

```bash
# 1) Build a structured paper spec
python scripts/build_paper_spec.py \
  --paper paper/paper.pdf \
  --title "Target Paper" \
  --paper-type empirical_ml \
  --stage draft \
  --target-venue neurips \
  --datasets cifar10 \
  --metrics accuracy,f1 \
  --sections title,abstract,introduction,related_work,methods,experiments,results,limitations,conclusion,references \
  --output paper/paper_spec.json

# 2) Run a manuscript quality gate
python scripts/paper_quality_gate.py \
  --paper-spec paper/paper_spec.json \
  --output-json analysis/quality_gate.json \
  --output-md analysis/quality_gate.md

# 3) Convert quality-gate output into a revision plan
python scripts/make_revision_plan.py \
  --quality-gate analysis/quality_gate.json \
  --paper-spec paper/paper_spec.json \
  --output-jsonl analysis/revision_plan.jsonl \
  --output-md analysis/revision_plan.md

# 4) Build a claim-evidence table
python scripts/claim_evidence_matrix.py \
  --paper-spec paper/paper_spec.json \
  --evidence-json analysis/evidence.json \
  --output-csv analysis/claim_evidence.csv \
  --output-md analysis/claim_evidence.md

# 5) Structure reviewer comments into a response matrix
python scripts/review_response_matrix.py \
  --reviews-json review/comments.json \
  --output-csv review/response_matrix.csv \
  --output-md review/response_matrix.md

# 6) Run repro gate for empirical papers
python scripts/repro_gate.py \
  --paper-spec paper/paper_spec.json \
  --output-json paper/repro_status.json \
  --output-md paper/repro_status.md

# 7) Analyze completed runs
python scripts/analyze_results.py \
  --runs-csv runs/results.csv \
  --baseline baseline \
  --lower-is-better-metrics perplexity,error_rate,wer \
  --output-json analysis/summary.json \
  --output-md analysis/summary.md

# 8) Refresh related literature
python scripts/lit_refresh.py \
  --query "target method + dataset" \
  --from-year 2023 \
  --max-results 15 \
  --output-jsonl lit/results.jsonl \
  --output-md lit/results.md
```

## Resource map

- `references/workflow.md`: multi-mode operational workflow and exit criteria.
- `references/manuscript_rubric.md`: scoring rubric by paper type.
- `references/section_playbook.md`: section-by-section revision guidance.
- `references/reporting_requirements.md`: venue and study-type guidance and how to fetch current official requirements.
- `references/reviewer_response.md`: rebuttal and response tactics.
- `references/schemas.md`: schemas for paper spec, quality gate, revision plan, claim matrix, reviewer-response matrix, and runs CSV.
- `references/statistics.md`: comparison and reporting defaults for empirical claims.
- `assets/revision_plan_template.md`: template for the main revision plan.
- `assets/reviewer_response_template.md`: template for reviewer-point responses.
- `assets/claim_evidence_table_template.md`: template for claim verification.
- `assets/submission_readiness_checklist.md`: final pre-submission gate.
- `assets/reproducibility_checklist.md`: pre-submission reproducibility checklist.
- `assets/pr_review_checklist.md`: evidence and engineering checklist before merging claim-facing changes.
- `assets/experiment.yaml`: baseline experiment template.
- `assets/ci_github_actions_ci.yml`: CI starter for smoke reproducibility.
