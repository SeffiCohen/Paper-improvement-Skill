# Revision Plan

## Context
- Paper title:
- Stage:
- Target venue:
- Paper type:

## Snapshot
- Current strength:
- Main acceptance risks:

## Blockers
| priority | issue | why it matters | fix | owner | evidence needed |
|---:|---|---|---|---|---|
| 1 |  |  |  |  |  |

## Major Revisions
| priority | issue | why it matters | fix | owner | evidence needed |
|---:|---|---|---|---|---|
| 2 |  |  |  |  |  |

## Exact Rewrite Tasks
- title:
- abstract:
- introduction:
- related work:
- methods:
- results:
- limitations:
- conclusion:

## Empirical Tasks
- baseline or ablation gaps:
- statistics gaps:
- reproducibility gaps:

## Final Pre-Submission Checks
- claims aligned to evidence:
- venue rules checked:
- availability statements present:
- reviewer-response matrix updated if relevant:
