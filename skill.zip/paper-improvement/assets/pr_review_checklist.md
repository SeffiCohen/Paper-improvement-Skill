# PR Review Checklist

## Intent

- Hypothesis under test:
- Claim affected:
- Scope (writing/training/evaluation/both):
- Target venue impact:

## Claim Alignment

- Abstract and introduction updated if the headline claim changed:
- Claim-evidence table updated:
- Any narrowed claim reflected consistently across sections:

## Reproducibility

- Config committed:
- Git SHA recorded in logs:
- Dataset version and checksum recorded:
- Exact rerun command captured:

## Evidence

- Baseline comparison included:
- Multi-seed evidence included:
- Metric implementation changes documented:
- Figure or table captions updated if reviewer-visible results changed:

## Statistics

- Confidence intervals included:
- Metric direction declared:
- Multiple-comparison policy documented (if needed):

## Reporting

- Data or code availability text updated:
- License or artifact notes updated:
- Limitations text updated if scope changed:

## Engineering

- Unit tests updated:
- CI smoke run passed:
- Artifacts attached:

## Risk

- Data leakage risk checked:
- Split comparability preserved:
- Compute impact documented:
- Venue-compliance risk checked:
