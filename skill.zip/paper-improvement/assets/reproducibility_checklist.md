# Reproducibility Checklist

## Paper Metadata

- Title:
- Version (arXiv v#, DOI, conference camera-ready tag):
- Target venue:
- Code URL in paper:
- Main claims and anchors (table, figure, theorem, appendix):

## Data

- Dataset names and versions:
- Source URLs and licenses:
- Split definitions and checksums:
- Preprocessing and filters:
- Leakage checks:
- Data availability statement text:

## Method

- Architecture details:
- Loss function terms and weights:
- Optimizer and schedule:
- Regularization:
- Augmentations:
- Exact rerun command:

## Compute and Environment

- Hardware details:
- Framework versions:
- Environment lockfile or container digest:
- Determinism settings and caveats:

## Evaluation

- Metric definitions:
- Metric direction (higher or lower is better):
- Aggregation policy:
- Seed policy and values:
- Statistical plan (CI and tests):

## Artifacts and Availability

- Code availability statement:
- Data availability statement:
- Artifact license:
- README or runbook exists:

## Reproduction Status

- Baseline within tolerance: yes/no
- If no, top mismatch causes:
- Open questions for human review:
