# Claim-Evidence Table

| claim_id | claim | anchor | support_type | evidence_location | support_status | risk_notes | required_action |
|---|---|---|---|---|---|---|---|
| C1 |  |  |  |  |  |  |  |
