# Submission Readiness Checklist

## Narrative
- Title is precise and not broader than the evidence.
- Abstract matches the strongest supported claims.
- Introduction states explicit contributions.
- Related work covers the strongest adjacent papers.

## Evidence
- Main claims are linked to tables, figures, theorems, or appendices.
- Baselines are fair and current enough for the venue.
- Uncertainty or robustness evidence is reported for claim-facing results.
- Failure modes or negative results are discussed when scope depends on them.

## Reporting
- Methods contain the details needed to interpret and reproduce the work.
- Limitations are explicit.
- Ethics, approvals, or broader-impact language is present if relevant.
- Data, code, and license statements are present if relevant.

## Venue
- Current official venue or journal rules have been checked.
- Formatting, anonymity, and checklist requirements are satisfied.
- Supplementary material and artifact packaging match the venue policy.
