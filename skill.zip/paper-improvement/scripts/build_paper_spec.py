#!/usr/bin/env python3
"""Build a normalized paper_spec.json template for academic paper-improvement workflows."""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


EMPIRICAL_PAPER_TYPES = {
    "empirical",
    "empirical_ml",
    "ml",
    "ai",
    "ai_ml",
    "empirical_cs",
    "systems",
    "benchmark",
    "vision",
    "nlp",
    "speech",
    "robotics",
}

HUMAN_OR_REGULATED_TYPES = {
    "clinical",
    "health",
    "human_subjects",
    "qualitative",
    "observational",
    "randomized_trial",
    "rct",
    "systematic_review",
    "meta_analysis",
}


def parse_csv_list(raw: str | None) -> list[str]:
    if not raw:
        return []
    return [item.strip() for item in raw.split(",") if item.strip()]



def load_json_dict(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"Expected JSON object in {path}")
    return data



def load_json_list(path: Path) -> list[Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, list):
        raise ValueError(f"Expected JSON list in {path}")
    return data



def deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    for key, value in override.items():
        if key in base and isinstance(base[key], dict) and isinstance(value, dict):
            base[key] = deep_merge(base[key], value)
        else:
            base[key] = value
    return base



def normalize_sections(raw: Any) -> list[str]:
    sections: list[str] = []
    if isinstance(raw, str):
        sections = parse_csv_list(raw)
    elif isinstance(raw, list):
        sections = [str(item).strip() for item in raw if str(item).strip()]
    elif isinstance(raw, dict):
        sections = [str(key).strip() for key, value in raw.items() if value and str(key).strip()]
    return sorted({section.lower() for section in sections})



def is_empirical(spec: dict[str, Any]) -> bool:
    metadata = spec.get("metadata", {})
    extraction = spec.get("extraction", {})
    paper_type = str(metadata.get("paper_type", "")).strip().lower()

    if paper_type in EMPIRICAL_PAPER_TYPES:
        return True

    return bool(extraction.get("datasets") or extraction.get("metrics") or extraction.get("baselines"))



def requires_ethics_reporting(spec: dict[str, Any]) -> bool:
    metadata = spec.get("metadata", {})
    paper_type = str(metadata.get("paper_type", "")).strip().lower()
    study_design = str(metadata.get("study_design", "")).strip().lower()
    return paper_type in HUMAN_OR_REGULATED_TYPES or study_design in HUMAN_OR_REGULATED_TYPES



def unresolved_fields(spec: dict[str, Any]) -> list[str]:
    missing: list[str] = []

    metadata = spec.get("metadata", {})
    extraction = spec.get("extraction", {})
    training = extraction.get("training", {})
    evaluation = extraction.get("evaluation", {})
    manuscript = spec.get("manuscript", {})
    availability = manuscript.get("availability", {})
    sections = normalize_sections(manuscript.get("sections", []))

    checks: list[tuple[str, Any]] = [
        ("metadata.title", metadata.get("title")),
        ("metadata.paper_path", metadata.get("paper_path")),
        ("extraction.claims", extraction.get("claims")),
        ("manuscript.sections", sections),
    ]

    if is_empirical(spec):
        checks.extend(
            [
                ("extraction.datasets", extraction.get("datasets")),
                ("extraction.metrics", extraction.get("metrics")),
                ("extraction.training.optimizer", training.get("optimizer")),
                ("extraction.training.learning_rate", training.get("learning_rate")),
                ("extraction.evaluation.seed_policy", evaluation.get("seed_policy")),
                ("extraction.evaluation.splits", evaluation.get("splits")),
                ("manuscript.availability.limitations", availability.get("limitations")),
            ]
        )

    if requires_ethics_reporting(spec):
        checks.append(("manuscript.availability.ethics", availability.get("ethics")))

    for key, value in checks:
        if value in (None, "", [], {}):
            missing.append(key)

    return missing



def build_markdown(spec: dict[str, Any]) -> str:
    metadata = spec.get("metadata", {})
    extraction = spec.get("extraction", {})
    manuscript = spec.get("manuscript", {})
    evaluation = extraction.get("evaluation", {})
    review_context = manuscript.get("review_context", {})
    availability = manuscript.get("availability", {})

    claims = extraction.get("claims", [])
    claims_lines = []
    for claim in claims:
        claim_id = claim.get("id", "unlabeled")
        text = claim.get("claim_text", "")
        metric = claim.get("metric", "")
        dataset = claim.get("dataset", "")
        value = claim.get("reported_value", "")
        anchor = claim.get("anchor", "")
        claims_lines.append(
            f"- {claim_id}: {text} | metric={metric} | dataset={dataset} | value={value} | anchor={anchor}"
        )

    unresolved = spec.get("unresolved_fields", [])
    sections = normalize_sections(manuscript.get("sections", []))

    lines = [
        "# Paper Spec Summary",
        "",
        "## Metadata",
        f"- Title: {metadata.get('title', '')}",
        f"- Paper path: {metadata.get('paper_path', '')}",
        f"- Paper ID: {metadata.get('paper_id', '')}",
        f"- arXiv ID: {metadata.get('arxiv_id', '')}",
        f"- DOI: {metadata.get('doi', '')}",
        f"- Code URL: {metadata.get('code_url', '')}",
        f"- Target venue: {metadata.get('target_venue', '')}",
        f"- Paper type: {metadata.get('paper_type', '')}",
        f"- Study design: {metadata.get('study_design', '')}",
        f"- Stage: {metadata.get('stage', '')}",
        f"- Keywords: {', '.join(metadata.get('keywords', []))}",
        "",
        "## Extraction",
        f"- Method summary: {extraction.get('method_summary', '')}",
        f"- Contributions: {', '.join(extraction.get('contributions', []))}",
        f"- Datasets: {', '.join(extraction.get('datasets', []))}",
        f"- Metrics: {', '.join(extraction.get('metrics', []))}",
        f"- Baselines: {', '.join(extraction.get('baselines', []))}",
        f"- Primary metric: {evaluation.get('primary_metric', '')}",
        f"- Primary dataset: {evaluation.get('primary_dataset', '')}",
        "",
        "## Manuscript",
        f"- Sections: {', '.join(sections)}",
        f"- Review comment count: {review_context.get('review_comment_count', 0)}",
        f"- Data availability: {availability.get('data', '')}",
        f"- Code availability: {availability.get('code', '')}",
        f"- License info: {availability.get('license', '')}",
        f"- Limitations: {availability.get('limitations', '')}",
        f"- Ethics: {availability.get('ethics', '')}",
        f"- Broader impacts: {availability.get('broader_impacts', '')}",
        "",
        "## Claims",
    ]

    lines.extend(claims_lines or ["- None yet"])
    lines.extend(
        [
            "",
            "## Unresolved Fields",
            *([f"- {item}" for item in unresolved] if unresolved else ["- None"]),
            "",
            "## Lineage",
            f"- Generated at: {spec.get('lineage', {}).get('generated_at', '')}",
            f"- Generator: {spec.get('lineage', {}).get('generator', '')}",
        ]
    )

    return "\n".join(lines) + "\n"



def default_availability() -> dict[str, str]:
    return {
        "data": "",
        "code": "",
        "license": "",
        "artifacts": "",
        "limitations": "",
        "ethics": "",
        "broader_impacts": "",
        "conflicts": "",
        "funding": "",
    }



def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--paper", required=True, help="Path to paper PDF or source manuscript")
    parser.add_argument("--title", default="")
    parser.add_argument("--paper-id", default="")
    parser.add_argument("--arxiv-id", default="")
    parser.add_argument("--doi", default="")
    parser.add_argument("--code-url", default="")
    parser.add_argument("--target-venue", default="")
    parser.add_argument("--paper-type", default="")
    parser.add_argument("--study-design", default="")
    parser.add_argument("--stage", default="")
    parser.add_argument("--keywords", default="", help="Comma-separated")
    parser.add_argument("--method-summary", default="")
    parser.add_argument("--datasets", default="", help="Comma-separated")
    parser.add_argument("--metrics", default="", help="Comma-separated")
    parser.add_argument("--baselines", default="", help="Comma-separated")
    parser.add_argument("--contributions", default="", help="Comma-separated")
    parser.add_argument("--primary-metric", default="")
    parser.add_argument("--primary-dataset", default="")
    parser.add_argument("--seed-policy", default="")
    parser.add_argument("--seed-values", default="", help="Comma-separated integers")
    parser.add_argument("--splits", default="", help="Comma-separated split names")
    parser.add_argument("--sections", default="", help="Comma-separated section names")
    parser.add_argument(
        "--claims-json",
        default="",
        help="Path to JSON file containing a list of claim objects",
    )
    parser.add_argument(
        "--availability-json",
        default="",
        help="Path to JSON file containing manuscript availability metadata",
    )
    parser.add_argument(
        "--review-comments-json",
        default="",
        help="Path to JSON file containing a list of reviewer comments",
    )
    parser.add_argument(
        "--merge-json",
        action="append",
        default=[],
        help="Additional JSON objects to deep-merge into the spec",
    )
    parser.add_argument("--output", required=True, help="Output paper_spec.json path")
    parser.add_argument(
        "--markdown-output",
        default="",
        help="Optional summary markdown path; defaults to <output>.md",
    )
    args = parser.parse_args()

    claims: list[dict[str, Any]] = []
    if args.claims_json:
        loaded_claims = load_json_list(Path(args.claims_json))
        claims = [dict(item) for item in loaded_claims if isinstance(item, dict)]

    seed_values: list[int] = []
    if args.seed_values:
        seed_values = [int(item.strip()) for item in args.seed_values.split(",") if item.strip()]

    availability = default_availability()
    if args.availability_json:
        availability = deep_merge(availability, load_json_dict(Path(args.availability_json)))

    if args.code_url and not availability.get("code"):
        availability["code"] = "linked"

    review_context = {
        "review_comments_path": str(Path(args.review_comments_json)) if args.review_comments_json else "",
        "review_comment_count": 0,
    }
    if args.review_comments_json:
        review_context["review_comment_count"] = len(load_json_list(Path(args.review_comments_json)))

    spec: dict[str, Any] = {
        "metadata": {
            "title": args.title,
            "paper_path": str(Path(args.paper)),
            "paper_id": args.paper_id,
            "arxiv_id": args.arxiv_id,
            "doi": args.doi,
            "code_url": args.code_url,
            "target_venue": args.target_venue,
            "paper_type": args.paper_type,
            "study_design": args.study_design,
            "stage": args.stage,
            "keywords": parse_csv_list(args.keywords),
        },
        "extraction": {
            "method_summary": args.method_summary,
            "contributions": parse_csv_list(args.contributions),
            "datasets": parse_csv_list(args.datasets),
            "metrics": parse_csv_list(args.metrics),
            "baselines": parse_csv_list(args.baselines),
            "claims": claims,
            "training": {
                "optimizer": "",
                "learning_rate": "",
                "batch_size": "",
                "epochs": "",
                "scheduler": "",
            },
            "evaluation": {
                "primary_metric": args.primary_metric,
                "primary_dataset": args.primary_dataset,
                "seed_policy": args.seed_policy,
                "seed_values": seed_values,
                "splits": parse_csv_list(args.splits),
            },
        },
        "manuscript": {
            "sections": normalize_sections(args.sections),
            "availability": availability,
            "review_context": review_context,
        },
        "unresolved_fields": [],
        "lineage": {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "generator": "build_paper_spec.py",
        },
    }

    for merge_file in args.merge_json:
        spec = deep_merge(spec, load_json_dict(Path(merge_file)))

    spec["unresolved_fields"] = unresolved_fields(spec)

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(spec, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")

    md_path = Path(args.markdown_output) if args.markdown_output else output_path.with_suffix(".md")
    md_path.write_text(build_markdown(spec), encoding="utf-8")

    print(f"Wrote {output_path}")
    print(f"Wrote {md_path}")


if __name__ == "__main__":
    main()
