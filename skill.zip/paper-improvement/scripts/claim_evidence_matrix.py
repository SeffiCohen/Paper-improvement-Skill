#!/usr/bin/env python3
"""Build a structured claim-evidence matrix and flag unsupported or overstated claims."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any



def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))



def load_claims(paper_spec: str, claims_json: str) -> list[dict[str, Any]]:
    if paper_spec:
        spec = load_json(Path(paper_spec))
        claims = spec.get("extraction", {}).get("claims", [])
        if not isinstance(claims, list):
            raise ValueError("paper spec extraction.claims must be a list")
        return [dict(item) for item in claims if isinstance(item, dict)]

    if claims_json:
        claims = load_json(Path(claims_json))
        if not isinstance(claims, list):
            raise ValueError("claims json must be a list")
        return [dict(item) for item in claims if isinstance(item, dict)]

    raise ValueError("Provide either --paper-spec or --claims-json")



def load_evidence(path_value: str) -> list[dict[str, Any]]:
    if not path_value:
        return []
    data = load_json(Path(path_value))
    if not isinstance(data, list):
        raise ValueError("evidence json must be a list")
    return [dict(item) for item in data if isinstance(item, dict)]



def truthy_support(row: dict[str, Any]) -> bool:
    supports = row.get("supports")
    if supports is True:
        return True
    strength = str(row.get("strength", "")).strip().lower()
    return strength in {"strong", "partial", "weak", "supports"}



def contradictory_support(row: dict[str, Any]) -> bool:
    supports = row.get("supports")
    if supports is False:
        return True
    strength = str(row.get("strength", "")).strip().lower()
    return strength in {"contradicts", "contradiction"}



def claim_status(claim: dict[str, Any], evidence_rows: list[dict[str, Any]]) -> str:
    has_anchor = bool(str(claim.get("anchor", "")).strip())
    positive = [row for row in evidence_rows if truthy_support(row)]
    negative = [row for row in evidence_rows if contradictory_support(row)]

    if negative and not positive:
        return "OVERSTATED"
    if positive and has_anchor:
        return "SUPPORTED"
    if positive or has_anchor:
        return "PARTIAL"
    return "UNSUPPORTED"



def missing_fields(claim: dict[str, Any]) -> list[str]:
    fields = []
    if not str(claim.get("id", "")).strip():
        fields.append("id")
    if not str(claim.get("claim_text", "")).strip():
        fields.append("claim_text")
    if not str(claim.get("anchor", "")).strip():
        fields.append("anchor")
    return fields



def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--paper-spec", default="")
    parser.add_argument("--claims-json", default="")
    parser.add_argument("--evidence-json", default="")
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--output-md", required=True)
    args = parser.parse_args()

    claims = load_claims(args.paper_spec, args.claims_json)
    evidence_rows = load_evidence(args.evidence_json)

    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in evidence_rows:
        claim_id = str(row.get("claim_id", "")).strip()
        if not claim_id:
            continue
        grouped.setdefault(claim_id, []).append(row)

    output_rows: list[dict[str, str]] = []
    for claim in claims:
        claim_id = str(claim.get("id", "") or "unlabeled").strip()
        rows = grouped.get(claim_id, [])
        status = claim_status(claim, rows)
        missing = missing_fields(claim)
        risk_notes: list[str] = []
        if str(claim.get("risk_note", "")).strip():
            risk_notes.append(str(claim.get("risk_note", "")).strip())
        for row in rows:
            note = str(row.get("risk_note", "")).strip()
            if note:
                risk_notes.append(note)

        output_rows.append(
            {
                "claim_id": claim_id,
                "claim_text": str(claim.get("claim_text", "")).strip(),
                "anchor": str(claim.get("anchor", "")).strip(),
                "status": status,
                "evidence_count": str(len(rows)),
                "missing_fields": ", ".join(missing),
                "risk_notes": " ; ".join(dict.fromkeys(risk_notes)),
            }
        )

    output_csv = Path(args.output_csv)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    with output_csv.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "claim_id",
                "claim_text",
                "anchor",
                "status",
                "evidence_count",
                "missing_fields",
                "risk_notes",
            ],
        )
        writer.writeheader()
        writer.writerows(output_rows)

    status_counts: dict[str, int] = {"SUPPORTED": 0, "PARTIAL": 0, "UNSUPPORTED": 0, "OVERSTATED": 0}
    for row in output_rows:
        status_counts[row["status"]] += 1

    lines = [
        "# Claim-Evidence Matrix",
        "",
        f"- Supported: {status_counts['SUPPORTED']}",
        f"- Partial: {status_counts['PARTIAL']}",
        f"- Unsupported: {status_counts['UNSUPPORTED']}",
        f"- Overstated: {status_counts['OVERSTATED']}",
        "",
        "| claim_id | status | evidence_count | anchor | missing_fields | risk_notes |",
        "|---|---|---:|---|---|---|",
    ]
    for row in output_rows:
        lines.append(
            "| {claim_id} | {status} | {evidence_count} | {anchor} | {missing_fields} | {risk_notes} |".format(
                claim_id=row["claim_id"],
                status=row["status"],
                evidence_count=row["evidence_count"],
                anchor=row["anchor"].replace("|", " "),
                missing_fields=row["missing_fields"].replace("|", " "),
                risk_notes=row["risk_notes"].replace("|", " "),
            )
        )

    output_md = Path(args.output_md)
    output_md.parent.mkdir(parents=True, exist_ok=True)
    output_md.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"Wrote {output_csv}")
    print(f"Wrote {output_md}")


if __name__ == "__main__":
    main()
