#!/usr/bin/env python3
"""Evaluate a paper spec against reproducibility gate rules."""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


CRITICAL_PATHS = [
    "metadata.title",
    "metadata.paper_path",
    "extraction.datasets",
    "extraction.metrics",
    "extraction.claims",
]

RECOMMENDED_PATHS = [
    "extraction.training.optimizer",
    "extraction.training.learning_rate",
    "extraction.training.batch_size",
    "extraction.training.epochs",
    "extraction.evaluation.seed_policy",
    "extraction.evaluation.splits",
    "manuscript.availability.data",
    "manuscript.availability.code",
]



def load_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"Expected JSON object in {path}")
    return data



def load_metric_map(value: str) -> dict[str, Any]:
    candidate = Path(value)
    if candidate.exists():
        return load_json(candidate)

    parsed = json.loads(value)
    if not isinstance(parsed, dict):
        raise ValueError("metric input must be a JSON object or a path to a JSON object")
    return parsed



def get_path(data: dict[str, Any], dotted: str) -> Any:
    current: Any = data
    for segment in dotted.split("."):
        if not isinstance(current, dict) or segment not in current:
            return None
        current = current[segment]
    return current



def is_missing(value: Any) -> bool:
    return value in (None, "", [], {})



def compare_metrics(
    paper_metrics: dict[str, float],
    run_metrics: dict[str, float],
    abs_tol: float,
    rel_tol: float,
) -> dict[str, Any]:
    report: dict[str, Any] = {"rows": [], "all_within_tolerance": True}

    for metric, paper_value in paper_metrics.items():
        row: dict[str, Any] = {
            "metric": metric,
            "paper_value": paper_value,
            "run_value": None,
            "abs_delta": None,
            "rel_delta": None,
            "within_tolerance": False,
            "note": "",
        }

        if metric not in run_metrics:
            row["note"] = "missing run metric"
            report["all_within_tolerance"] = False
            report["rows"].append(row)
            continue

        run_value = run_metrics[metric]
        abs_delta = abs(run_value - paper_value)
        rel_delta = abs_delta / max(abs(paper_value), 1e-12)
        within = abs_delta <= abs_tol or rel_delta <= rel_tol

        row.update(
            {
                "run_value": run_value,
                "abs_delta": abs_delta,
                "rel_delta": rel_delta,
                "within_tolerance": within,
            }
        )

        if not within:
            row["note"] = "outside tolerance"
            report["all_within_tolerance"] = False

        report["rows"].append(row)

    return report



def build_questions(missing_critical: list[str], metric_comparison: dict[str, Any]) -> list[str]:
    questions: list[str] = []

    for field in missing_critical:
        questions.append(f"Provide missing critical field: {field}")

    if metric_comparison and not metric_comparison.get("all_within_tolerance", True):
        questions.append(
            "Reproduction mismatch detected. Confirm metric implementation, data splits, seed policy, and evaluation protocol."
        )

    if not questions:
        questions.append("No blocking questions. Approve baseline escalation if compute budget permits.")

    return questions



def write_markdown(
    output: Path,
    verdict: str,
    missing_critical: list[str],
    missing_recommended: list[str],
    metric_comparison: dict[str, Any] | None,
    questions: list[str],
) -> None:
    lines = [
        "# Reproducibility Gate Report",
        "",
        f"- Verdict: {verdict}",
        "",
        "## Missing Critical Fields",
        *([f"- {field}" for field in missing_critical] if missing_critical else ["- None"]),
        "",
        "## Missing Recommended Fields",
        *([f"- {field}" for field in missing_recommended] if missing_recommended else ["- None"]),
        "",
        "## Metric Comparison",
    ]

    if metric_comparison:
        rows = metric_comparison.get("rows", [])
        if rows:
            lines.append("| metric | paper | run | abs_delta | rel_delta | within | note |")
            lines.append("|---|---:|---:|---:|---:|---|---|")
            for row in rows:
                lines.append(
                    "| {metric} | {paper} | {run} | {abs_delta} | {rel_delta} | {within} | {note} |".format(
                        metric=row.get("metric", ""),
                        paper=row.get("paper_value", ""),
                        run=row.get("run_value", ""),
                        abs_delta=row.get("abs_delta", ""),
                        rel_delta=row.get("rel_delta", ""),
                        within=row.get("within_tolerance", ""),
                        note=row.get("note", ""),
                    )
                )
        else:
            lines.append("- No rows")
    else:
        lines.append("- Not provided")

    lines.extend(["", "## Questions For Human Review"])
    lines.extend(f"- {question}" for question in questions)
    output.write_text("\n".join(lines) + "\n", encoding="utf-8")



def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--paper-spec", required=True)
    parser.add_argument("--paper-metrics", default="", help="Path to JSON file or inline JSON object: metric -> value")
    parser.add_argument("--run-metrics", default="", help="Path to JSON file or inline JSON object: metric -> value")
    parser.add_argument("--abs-tolerance", type=float, default=0.02)
    parser.add_argument("--rel-tolerance", type=float, default=0.05)
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--output-md", required=True)
    args = parser.parse_args()

    spec = load_json(Path(args.paper_spec))

    missing_critical = [path for path in CRITICAL_PATHS if is_missing(get_path(spec, path))]
    missing_recommended = [path for path in RECOMMENDED_PATHS if is_missing(get_path(spec, path))]

    metric_comparison = None
    if args.paper_metrics and args.run_metrics:
        paper_metrics = load_metric_map(args.paper_metrics)
        run_metrics = load_metric_map(args.run_metrics)

        if not all(isinstance(value, (int, float)) for value in paper_metrics.values()):
            raise ValueError("--paper-metrics must be numeric")
        if not all(isinstance(value, (int, float)) for value in run_metrics.values()):
            raise ValueError("--run-metrics must be numeric")

        metric_comparison = compare_metrics(
            {key: float(value) for key, value in paper_metrics.items()},
            {key: float(value) for key, value in run_metrics.items()},
            args.abs_tolerance,
            args.rel_tolerance,
        )

    if missing_critical:
        verdict = "FAIL_BLOCKED"
    elif metric_comparison is None:
        verdict = "PASS_SMOKE"
    elif metric_comparison.get("all_within_tolerance", False):
        verdict = "PASS_BASELINE_TOLERANCE"
    else:
        verdict = "FAIL_MISMATCH"

    questions = build_questions(missing_critical, metric_comparison or {})

    report = {
        "verdict": verdict,
        "missing_critical": missing_critical,
        "missing_recommended": missing_recommended,
        "metric_comparison": metric_comparison,
        "questions_for_human": questions,
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }

    output_json = Path(args.output_json)
    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(report, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")

    output_md = Path(args.output_md)
    output_md.parent.mkdir(parents=True, exist_ok=True)
    write_markdown(
        output_md,
        verdict,
        missing_critical,
        missing_recommended,
        metric_comparison,
        questions,
    )

    print(f"Wrote {output_json}")
    print(f"Wrote {output_md}")


if __name__ == "__main__":
    main()
