#!/usr/bin/env python3
"""Check a structured paper spec for manuscript-quality and submission-readiness gaps."""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


CATEGORY_ORDER = [
    "contribution_scope",
    "structure_clarity",
    "evidence_alignment",
    "empirical_rigor",
    "reproducibility",
    "ethics_reporting",
]

SEVERITY_ORDER = {"blocker": 0, "major": 1, "moderate": 2, "info": 3}
PENALTIES = {"blocker": 2.0, "major": 1.0, "moderate": 0.5, "info": 0.0}

EMPIRICAL_TYPES = {
    "empirical",
    "empirical_ml",
    "ml",
    "ai",
    "ai_ml",
    "empirical_cs",
    "systems",
    "benchmark",
    "vision",
    "nlp",
    "speech",
    "robotics",
}

THEORY_TYPES = {"theory", "formal", "math"}
REVIEW_TYPES = {"survey", "review", "systematic_review", "meta_analysis"}
HUMAN_OR_REGULATED_TYPES = {
    "clinical",
    "health",
    "human_subjects",
    "qualitative",
    "observational",
    "randomized_trial",
    "rct",
    "systematic_review",
    "meta_analysis",
}



def load_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"Expected JSON object in {path}")
    return data



def normalize_text(value: Any) -> str:
    return str(value or "").strip().lower()



def normalize_sections(raw: Any) -> set[str]:
    sections: set[str] = set()
    if isinstance(raw, str):
        pieces = [item.strip() for item in raw.split(",") if item.strip()]
        sections.update(item.lower() for item in pieces)
    elif isinstance(raw, list):
        sections.update(str(item).strip().lower() for item in raw if str(item).strip())
    elif isinstance(raw, dict):
        sections.update(str(key).strip().lower() for key, value in raw.items() if value and str(key).strip())
    return sections



def has_section(sections: set[str], aliases: set[str]) -> bool:
    return any(alias in sections for alias in aliases)



def infer_paper_type(spec: dict[str, Any]) -> str:
    metadata = spec.get("metadata", {})
    extraction = spec.get("extraction", {})
    paper_type = normalize_text(metadata.get("paper_type"))
    if paper_type:
        return paper_type

    if extraction.get("datasets") or extraction.get("metrics") or extraction.get("baselines"):
        return "empirical"

    return "general"



def is_empirical(spec: dict[str, Any], paper_type: str) -> bool:
    if paper_type in EMPIRICAL_TYPES:
        return True
    if paper_type in THEORY_TYPES | REVIEW_TYPES:
        return False
    extraction = spec.get("extraction", {})
    return bool(extraction.get("datasets") or extraction.get("metrics") or extraction.get("baselines"))



def requires_ethics_reporting(spec: dict[str, Any], paper_type: str) -> bool:
    metadata = spec.get("metadata", {})
    study_design = normalize_text(metadata.get("study_design"))
    return paper_type in HUMAN_OR_REGULATED_TYPES or study_design in HUMAN_OR_REGULATED_TYPES



def add_issue(
    issues: list[dict[str, str]],
    severity: str,
    category: str,
    code: str,
    message: str,
    recommended_action: str,
) -> None:
    issues.append(
        {
            "severity": severity,
            "category": category,
            "code": code,
            "message": message,
            "recommended_action": recommended_action,
        }
    )



def summarize_scores(issues: list[dict[str, str]]) -> dict[str, float]:
    scores = {category: 5.0 for category in CATEGORY_ORDER}
    for issue in issues:
        category = issue["category"]
        if category not in scores:
            continue
        scores[category] -= PENALTIES[issue["severity"]]
    return {key: round(max(0.0, value), 1) for key, value in scores.items()}



def issue_counts(issues: list[dict[str, str]]) -> dict[str, int]:
    counts = {severity: 0 for severity in SEVERITY_ORDER}
    for issue in issues:
        counts[issue["severity"]] += 1
    return counts



def readiness_label(counts: dict[str, int]) -> str:
    if counts["blocker"]:
        return "not_ready"
    if counts["major"] >= 3:
        return "major_revision"
    if counts["major"] or counts["moderate"] >= 3:
        return "revise"
    return "polish"



def recommended_modes(spec: dict[str, Any], empirical: bool) -> list[str]:
    modes = ["draft_critique", "deep_revision"]
    review_context = spec.get("manuscript", {}).get("review_context", {})
    if int(review_context.get("review_comment_count", 0) or 0) > 0:
        modes.append("review_response")
    if empirical:
        modes.append("empirical_integrity")
    if normalize_text(spec.get("metadata", {}).get("target_venue")):
        modes.append("venue_targeting")
    return modes



def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--paper-spec", required=True)
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--output-md", required=True)
    args = parser.parse_args()

    spec = load_json(Path(args.paper_spec))
    metadata = spec.get("metadata", {})
    extraction = spec.get("extraction", {})
    manuscript = spec.get("manuscript", {})
    availability = manuscript.get("availability", {})
    evaluation = extraction.get("evaluation", {})
    training = extraction.get("training", {})
    claims = extraction.get("claims", []) if isinstance(extraction.get("claims", []), list) else []
    unresolved = spec.get("unresolved_fields", []) if isinstance(spec.get("unresolved_fields", []), list) else []

    paper_type = infer_paper_type(spec)
    empirical = is_empirical(spec, paper_type)
    requires_ethics = requires_ethics_reporting(spec, paper_type)
    sections = normalize_sections(manuscript.get("sections", []))

    issues: list[dict[str, str]] = []

    if not normalize_text(metadata.get("title")):
        add_issue(
            issues,
            "blocker",
            "contribution_scope",
            "MISSING_TITLE",
            "The paper spec does not record a title.",
            "Record the exact paper title so all revision artifacts stay aligned.",
        )

    if not has_section(sections, {"title"}):
        add_issue(
            issues,
            "moderate",
            "structure_clarity",
            "TITLE_SECTION_NOT_MARKED",
            "The section inventory does not explicitly mark a title section.",
            "Record the manuscript sections explicitly so structural checks are reliable.",
        )

    if not has_section(sections, {"abstract"}):
        add_issue(
            issues,
            "blocker",
            "structure_clarity",
            "MISSING_ABSTRACT",
            "The manuscript does not list an abstract section.",
            "Add or extract the abstract before attempting final paper improvement.",
        )

    if not has_section(sections, {"introduction", "intro"}):
        add_issue(
            issues,
            "blocker",
            "structure_clarity",
            "MISSING_INTRODUCTION",
            "The manuscript does not list an introduction section.",
            "Add or extract the introduction so the paper's problem framing and contributions can be checked.",
        )

    if not claims:
        add_issue(
            issues,
            "blocker",
            "evidence_alignment",
            "NO_CLAIMS",
            "No structured main claims were extracted from the paper.",
            "Create a short list of headline claims with anchors to the manuscript and the evidence supporting them.",
        )
    else:
        claims_missing_anchor = [claim.get("id", "unlabeled") for claim in claims if not normalize_text(claim.get("anchor"))]
        claims_missing_text = [claim.get("id", "unlabeled") for claim in claims if not normalize_text(claim.get("claim_text"))]
        if claims_missing_text:
            add_issue(
                issues,
                "major",
                "contribution_scope",
                "CLAIMS_MISSING_TEXT",
                f"Some structured claims are incomplete: {', '.join(claims_missing_text[:5])}.",
                "Fill in the actual claim text for every structured claim.",
            )
        if claims_missing_anchor:
            severity = "major" if len(claims_missing_anchor) >= max(1, len(claims) // 2) else "moderate"
            add_issue(
                issues,
                severity,
                "evidence_alignment",
                "CLAIMS_MISSING_ANCHORS",
                f"Some claims do not point to a table, figure, theorem, or appendix anchor: {', '.join(claims_missing_anchor[:5])}.",
                "Add a concrete anchor for each claim so the paper's evidence can be audited quickly.",
            )

    if not extraction.get("contributions"):
        add_issue(
            issues,
            "moderate",
            "contribution_scope",
            "CONTRIBUTIONS_NOT_LISTED",
            "The paper spec does not list explicit contributions.",
            "Write two to five contribution bullets so abstract, introduction, and conclusion can be aligned.",
        )

    if not has_section(sections, {"related_work", "related", "background"}):
        add_issue(
            issues,
            "major",
            "contribution_scope",
            "MISSING_RELATED_WORK",
            "The manuscript does not list a related-work or background section.",
            "Add a related-work section or make the comparison against adjacent work explicit in the introduction.",
        )

    if not has_section(sections, {"limitations", "discussion"}):
        add_issue(
            issues,
            "major",
            "ethics_reporting",
            "MISSING_LIMITATIONS",
            "The manuscript does not list a limitations or discussion section.",
            "Add an honest limitations discussion covering boundary conditions and likely failure modes.",
        )

    if not has_section(sections, {"conclusion", "conclusions"}):
        add_issue(
            issues,
            "moderate",
            "structure_clarity",
            "MISSING_CONCLUSION",
            "The manuscript does not list a conclusion section.",
            "Add or restore a conclusion that summarizes only what the paper actually established.",
        )

    if empirical:
        if not has_section(sections, {"methods", "method", "approach", "model", "setup"}):
            add_issue(
                issues,
                "blocker",
                "empirical_rigor",
                "MISSING_METHODS",
                "The empirical paper does not list a methods or approach section.",
                "Add a methods section with assumptions, setup, and implementation details needed to interpret the results.",
            )

        if not has_section(sections, {"experiments", "evaluation", "results"}):
            add_issue(
                issues,
                "blocker",
                "empirical_rigor",
                "MISSING_RESULTS_SECTION",
                "The empirical paper does not list experiments, evaluation, or results sections.",
                "Add or identify the section where the main evidence is reported.",
            )

        if not extraction.get("datasets"):
            add_issue(
                issues,
                "major",
                "empirical_rigor",
                "NO_DATASETS",
                "The paper spec does not list datasets or evaluation corpora.",
                "Record the datasets or evaluation environments explicitly.",
            )

        if not extraction.get("metrics"):
            add_issue(
                issues,
                "major",
                "empirical_rigor",
                "NO_METRICS",
                "The paper spec does not list evaluation metrics.",
                "Record the metrics and their definitions before claiming improvements.",
            )

        if not extraction.get("baselines"):
            add_issue(
                issues,
                "major",
                "empirical_rigor",
                "NO_BASELINES",
                "The paper spec does not list baseline systems or comparison targets.",
                "Add the strongest adjacent baselines that are necessary to support the novelty story.",
            )

        if not normalize_text(evaluation.get("seed_policy")):
            add_issue(
                issues,
                "major",
                "empirical_rigor",
                "MISSING_SEED_POLICY",
                "The evaluation section does not record a seed policy.",
                "State whether results are single-seed or multi-seed and record the seed values when relevant.",
            )

        if not evaluation.get("splits"):
            add_issue(
                issues,
                "major",
                "empirical_rigor",
                "MISSING_SPLITS",
                "The evaluation section does not record data splits or evaluation partitions.",
                "Record split definitions, identifiers, or selection logic.",
            )

        if not training.get("optimizer") or not training.get("learning_rate"):
            add_issue(
                issues,
                "moderate",
                "empirical_rigor",
                "TRAINING_DETAILS_THIN",
                "Training details are incomplete in the paper spec.",
                "Record optimizer, learning rate, schedule, and other settings needed to reproduce central results.",
            )

        if not normalize_text(availability.get("data")):
            add_issue(
                issues,
                "major",
                "reproducibility",
                "MISSING_DATA_AVAILABILITY",
                "The empirical paper does not record a data availability statement or access path.",
                "Add a data availability statement that explains how the evaluation data can be accessed or why it is restricted.",
            )

        has_code_path = normalize_text(metadata.get("code_url")) or normalize_text(availability.get("code"))
        if not has_code_path:
            add_issue(
                issues,
                "major",
                "reproducibility",
                "MISSING_CODE_PATH",
                "The empirical paper does not record a code availability path or explanation.",
                "Add a code availability statement, a code URL, or a plain explanation of constraints.",
            )

    if not normalize_text(availability.get("license")):
        add_issue(
            issues,
            "moderate",
            "reproducibility",
            "MISSING_LICENSE_INFO",
            "The manuscript spec does not record license information for code, data, or released assets.",
            "Record the relevant licenses or terms of use for released or reused assets.",
        )

    if requires_ethics and not normalize_text(availability.get("ethics")):
        add_issue(
            issues,
            "major",
            "ethics_reporting",
            "MISSING_ETHICS_NOTE",
            "The paper appears to require ethics, approval, or participant-risk reporting, but none is recorded.",
            "Add ethics or approvals language appropriate to the study design and target venue.",
        )

    if paper_type in REVIEW_TYPES and not normalize_text(metadata.get("study_design")):
        add_issue(
            issues,
            "major",
            "ethics_reporting",
            "MISSING_STUDY_DESIGN",
            "The review-style paper does not record a study design or review type.",
            "Record whether the paper is a survey, systematic review, scoping review, or meta-analysis and use the matching reporting guidance.",
        )

    if not normalize_text(metadata.get("target_venue")):
        add_issue(
            issues,
            "info",
            "contribution_scope",
            "TARGET_VENUE_UNKNOWN",
            "No target venue is recorded.",
            "If a specific venue is known, fetch the current official requirements before the final polish pass.",
        )

    if unresolved:
        add_issue(
            issues,
            "moderate",
            "structure_clarity",
            "UNRESOLVED_FIELDS_PRESENT",
            f"The paper spec still has unresolved fields: {', '.join(unresolved[:6])}.",
            "Resolve or explicitly triage the remaining unknowns before finalizing claims and submission artifacts.",
        )

    issues.sort(key=lambda row: (SEVERITY_ORDER[row["severity"]], CATEGORY_ORDER.index(row["category"]), row["code"]))

    counts = issue_counts(issues)
    scores = summarize_scores(issues)
    payload = {
        "paper_type_inferred": paper_type,
        "empirical": empirical,
        "readiness": readiness_label(counts),
        "scores": scores,
        "issue_counts": counts,
        "issues": issues,
        "recommended_modes": recommended_modes(spec, empirical),
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }

    output_json = Path(args.output_json)
    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(payload, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")

    lines = [
        "# Paper Quality Gate",
        "",
        f"- Paper type inferred: {paper_type}",
        f"- Empirical paper: {empirical}",
        f"- Readiness: {payload['readiness']}",
        f"- Recommended modes: {', '.join(payload['recommended_modes'])}",
        "",
        "## Issue Counts",
        f"- Blockers: {counts['blocker']}",
        f"- Major: {counts['major']}",
        f"- Moderate: {counts['moderate']}",
        f"- Info: {counts['info']}",
        "",
        "## Category Scores",
        "| category | score |",
        "|---|---:|",
    ]
    for category, score in scores.items():
        lines.append(f"| {category} | {score:.1f} |")

    lines.extend(
        [
            "",
            "## Issues",
            "| severity | category | code | message | recommended_action |",
            "|---|---|---|---|---|",
        ]
    )
    for issue in issues:
        lines.append(
            "| {severity} | {category} | {code} | {message} | {action} |".format(
                severity=issue["severity"],
                category=issue["category"],
                code=issue["code"],
                message=issue["message"].replace("|", " "),
                action=issue["recommended_action"].replace("|", " "),
            )
        )

    output_md = Path(args.output_md)
    output_md.parent.mkdir(parents=True, exist_ok=True)
    output_md.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"Wrote {output_json}")
    print(f"Wrote {output_md}")


if __name__ == "__main__":
    main()
