#!/usr/bin/env python3
"""Generate a prioritized improvement proposal queue from paper and repro metadata."""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def load_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"Expected JSON object in {path}")
    return data


def pick_primary_metric(spec: dict[str, Any]) -> str:
    extraction = spec.get("extraction", {})
    evaluation = extraction.get("evaluation", {})

    metric = evaluation.get("primary_metric")
    if isinstance(metric, str) and metric.strip():
        return metric.strip()

    metrics = extraction.get("metrics", [])
    if isinstance(metrics, list) and metrics:
        return str(metrics[0])

    return "primary_metric"


def pick_primary_dataset(spec: dict[str, Any]) -> str:
    extraction = spec.get("extraction", {})
    evaluation = extraction.get("evaluation", {})

    dataset = evaluation.get("primary_dataset")
    if isinstance(dataset, str) and dataset.strip():
        return dataset.strip()

    datasets = extraction.get("datasets", [])
    if isinstance(datasets, list) and datasets:
        return str(datasets[0])

    return "primary_dataset"


def build_base_proposals(metric: str, dataset: str) -> list[dict[str, Any]]:
    return [
        {
            "id": "P001",
            "type": "ablation",
            "title": "Component ablation matrix",
            "rationale": "Isolate which method components carry most of the reported gain.",
            "required_changes": [
                "Create config variants that remove one component at a time",
                "Keep data split and seed policy fixed",
            ],
            "success_metric": f"No severe drop on {metric} for minimal components on {dataset}",
            "expected_cost_gpu_hours": 6.0,
            "risk": "medium",
            "stop_condition": "Stop if three top ablations all underperform baseline by >3%.",
            "impact": 0.85,
        },
        {
            "id": "P002",
            "type": "baseline",
            "title": "Stronger baseline inclusion",
            "rationale": "Validate gain against current strong baselines, not only paper-era baselines.",
            "required_changes": [
                "Add one modern reproducible baseline family",
                "Match training budget and evaluation protocol",
            ],
            "success_metric": f"Candidate improves {metric} over added baseline on {dataset}",
            "expected_cost_gpu_hours": 10.0,
            "risk": "medium",
            "stop_condition": "Stop if baseline dominates candidate after two seed groups.",
            "impact": 0.92,
        },
        {
            "id": "P003",
            "type": "hparam",
            "title": "Hyperparameter neighborhood sweep",
            "rationale": "Check whether reported settings are robust or fragile around local neighborhoods.",
            "required_changes": [
                "Sweep learning rate, weight decay, and warmup",
                "Use early stopping and pruning for low-value trials",
            ],
            "success_metric": f"Find stable region with >= baseline {metric}",
            "expected_cost_gpu_hours": 12.0,
            "risk": "low",
            "stop_condition": "Stop when top 20% trials converge within 1% performance range.",
            "impact": 0.78,
        },
        {
            "id": "P004",
            "type": "robustness",
            "title": "Seed and split robustness expansion",
            "rationale": "Reduce chance that gains come from favorable seed or split artifacts.",
            "required_changes": [
                "Expand to additional seeds",
                "Run alternate validation split if protocol permits",
            ],
            "success_metric": f"Gain persists with confidence interval above baseline on {metric}",
            "expected_cost_gpu_hours": 8.0,
            "risk": "low",
            "stop_condition": "Stop if confidence interval crosses zero after seed expansion.",
            "impact": 0.88,
        },
        {
            "id": "P005",
            "type": "efficiency",
            "title": "Efficiency-performance Pareto check",
            "rationale": "Measure whether smaller compute variants keep most of the performance.",
            "required_changes": [
                "Add reduced compute variant (batch, precision, or model size)",
                "Track throughput and total compute hours",
            ],
            "success_metric": "Preserve >=95% performance at materially lower compute cost",
            "expected_cost_gpu_hours": 4.0,
            "risk": "low",
            "stop_condition": "Stop if all variants lose >5% relative performance.",
            "impact": 0.70,
        },
    ]


def apply_context_adjustments(
    proposals: list[dict[str, Any]], repro_status: dict[str, Any] | None
) -> None:
    if not repro_status:
        return

    verdict = repro_status.get("verdict", "")
    if verdict == "FAIL_MISMATCH":
        for proposal in proposals:
            if proposal["type"] in {"ablation", "baseline"}:
                proposal["impact"] += 0.03
            if proposal["type"] == "hparam":
                proposal["impact"] -= 0.02

    if verdict == "FAIL_BLOCKED":
        for proposal in proposals:
            proposal["impact"] -= 0.05


def prioritize(proposals: list[dict[str, Any]], budget_gpu_hours: float) -> list[dict[str, Any]]:
    for proposal in proposals:
        cost = max(float(proposal["expected_cost_gpu_hours"]), 0.1)
        proposal["priority"] = round(float(proposal["impact"]) / cost, 3)

    proposals.sort(key=lambda item: item["priority"], reverse=True)

    cumulative = 0.0
    for proposal in proposals:
        cumulative += float(proposal["expected_cost_gpu_hours"])
        proposal["selected_in_budget"] = cumulative <= budget_gpu_hours

    return proposals


def write_jsonl(path: Path, proposals: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for proposal in proposals:
            clean = {k: v for k, v in proposal.items() if k != "impact"}
            handle.write(json.dumps(clean, ensure_ascii=True) + "\n")


def write_markdown(path: Path, proposals: list[dict[str, Any]], budget: float) -> None:
    lines = [
        "# Improvement Proposals",
        "",
        f"- Budget (GPU hours): {budget}",
        "",
        "| id | type | title | cost | priority | in_budget | success_metric |",
        "|---|---|---|---:|---:|---|---|",
    ]

    for proposal in proposals:
        lines.append(
            "| {id} | {type} | {title} | {cost} | {priority} | {selected} | {success_metric} |".format(
                id=proposal["id"],
                type=proposal["type"],
                title=proposal["title"],
                cost=proposal["expected_cost_gpu_hours"],
                priority=proposal["priority"],
                selected=proposal["selected_in_budget"],
                success_metric=proposal["success_metric"],
            )
        )

    lines.extend(
        [
            "",
            "## Notes",
            "- Keep at least one selected proposal from each category where feasible.",
            "- Require human approval before executing items with high operational risk.",
            f"- Generated at: {datetime.now(timezone.utc).isoformat()}",
        ]
    )

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--paper-spec", required=True)
    parser.add_argument("--repro-status", default="")
    parser.add_argument("--budget-gpu-hours", type=float, default=40.0)
    parser.add_argument("--output-jsonl", required=True)
    parser.add_argument("--output-md", required=True)
    args = parser.parse_args()

    spec = load_json(Path(args.paper_spec))
    repro_status = load_json(Path(args.repro_status)) if args.repro_status else None

    metric = pick_primary_metric(spec)
    dataset = pick_primary_dataset(spec)

    proposals = build_base_proposals(metric, dataset)
    apply_context_adjustments(proposals, repro_status)
    proposals = prioritize(proposals, args.budget_gpu_hours)

    write_jsonl(Path(args.output_jsonl), proposals)
    write_markdown(Path(args.output_md), proposals, args.budget_gpu_hours)

    print(f"Wrote {args.output_jsonl}")
    print(f"Wrote {args.output_md}")


if __name__ == "__main__":
    main()
