#!/usr/bin/env python3
"""Normalize reviewer comments into a structured response matrix."""

from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path
from typing import Any


THEME_KEYWORDS = {
    "contribution": ["novel", "novelty", "contribution", "incremental", "motivation", "significance"],
    "related_work": ["related work", "citation", "compare", "prior work", "literature"],
    "methods": ["assumption", "method", "algorithm", "proof", "theorem", "setup"],
    "evidence": ["baseline", "experiment", "ablation", "evaluation", "result", "benchmark"],
    "statistics": ["significant", "confidence", "variance", "error bar", "seed", "statistical"],
    "reproducibility": ["reproduce", "reproduc", "code", "data", "artifact", "appendix", "details"],
    "clarity": ["unclear", "clarify", "writing", "readability", "notation", "figure", "table", "typo"],
    "limitations_ethics": ["limitation", "ethic", "risk", "bias", "fairness", "privacy", "broader impact", "human subjects"],
}

DEFAULT_ACTIONS = {
    "contribution": ("tighten the contribution claim and clarify the novelty boundary", "introduction"),
    "related_work": ("add missing comparisons and sharpen positioning against adjacent work", "related work"),
    "methods": ("clarify assumptions, definitions, or implementation details", "methods"),
    "evidence": ("add or better explain the necessary experiment, baseline, or ablation", "results"),
    "statistics": ("add uncertainty, exact comparison details, and the declared statistical procedure", "results"),
    "reproducibility": ("add code, data, appendix, or rerun details, or explain the constraint clearly", "appendix"),
    "clarity": ("rewrite the affected text for directness and add missing figure or table explanation", "affected section"),
    "limitations_ethics": ("add limitations, ethics, or risk discussion matched to the paper's scope", "limitations"),
    "general": ("address the reviewer point directly and make the manuscript change explicit", "affected section"),
}



def load_reviews(path: Path) -> list[dict[str, Any]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, list):
        raise ValueError(f"Expected JSON list in {path}")
    return [dict(item) for item in data if isinstance(item, dict)]



def classify_theme(comment: str) -> str:
    lowered = comment.lower()
    for theme, keywords in THEME_KEYWORDS.items():
        if any(keyword in lowered for keyword in keywords):
            return theme
    return "general"



def infer_severity(theme: str, comment: str) -> str:
    lowered = comment.lower()
    if any(word in lowered for word in ["fatal", "invalid", "unsupported", "major concern", "incorrect"]):
        return "major"
    if theme in {"contribution", "evidence", "statistics", "reproducibility", "methods"}:
        return "major"
    if theme == "general":
        return "moderate"
    return "moderate"



def summarize_comment(comment: str, limit: int = 140) -> str:
    compact = re.sub(r"\s+", " ", comment).strip()
    if len(compact) <= limit:
        return compact
    return compact[: limit - 3].rstrip() + "..."



def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reviews-json", required=True)
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--output-md", required=True)
    args = parser.parse_args()

    reviews = load_reviews(Path(args.reviews_json))

    rows: list[dict[str, str]] = []
    for idx, review in enumerate(reviews, start=1):
        reviewer = str(review.get("reviewer", "reviewer")).strip() or "reviewer"
        comment_id = str(review.get("comment_id", f"C{idx}")).strip() or f"C{idx}"
        comment = str(review.get("comment", "")).strip()
        theme = str(review.get("theme", "")).strip() or classify_theme(comment)
        severity = str(review.get("severity", "")).strip() or infer_severity(theme, comment)
        planned_action, default_location = DEFAULT_ACTIONS.get(theme, DEFAULT_ACTIONS["general"])
        manuscript_location = str(review.get("manuscript_location", "")).strip() or default_location
        action = str(review.get("planned_action", "")).strip() or planned_action
        response_status = str(review.get("response_status", "")).strip() or "planned"
        evidence_needed = str(review.get("evidence_needed", "")).strip()
        summary = summarize_comment(comment)
        draft_response = (
            f"Thank you for this point. We will {action}. "
            f"This change will appear in {manuscript_location}."
        )

        rows.append(
            {
                "reviewer": reviewer,
                "comment_id": comment_id,
                "theme": theme,
                "severity": severity,
                "comment_summary": summary,
                "planned_action": action,
                "manuscript_location": manuscript_location,
                "response_status": response_status,
                "evidence_needed": evidence_needed,
                "draft_response": draft_response,
            }
        )

    output_csv = Path(args.output_csv)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    with output_csv.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "reviewer",
                "comment_id",
                "theme",
                "severity",
                "comment_summary",
                "planned_action",
                "manuscript_location",
                "response_status",
                "evidence_needed",
                "draft_response",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)

    lines = [
        "# Reviewer Response Matrix",
        "",
        "| reviewer | comment_id | theme | severity | comment_summary | planned_action | location | status | evidence_needed |",
        "|---|---|---|---|---|---|---|---|---|",
    ]
    for row in rows:
        lines.append(
            "| {reviewer} | {comment_id} | {theme} | {severity} | {summary} | {action} | {location} | {status} | {evidence} |".format(
                reviewer=row["reviewer"].replace("|", " "),
                comment_id=row["comment_id"].replace("|", " "),
                theme=row["theme"].replace("|", " "),
                severity=row["severity"].replace("|", " "),
                summary=row["comment_summary"].replace("|", " "),
                action=row["planned_action"].replace("|", " "),
                location=row["manuscript_location"].replace("|", " "),
                status=row["response_status"].replace("|", " "),
                evidence=row["evidence_needed"].replace("|", " "),
            )
        )

    output_md = Path(args.output_md)
    output_md.parent.mkdir(parents=True, exist_ok=True)
    output_md.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"Wrote {output_csv}")
    print(f"Wrote {output_md}")


if __name__ == "__main__":
    main()
