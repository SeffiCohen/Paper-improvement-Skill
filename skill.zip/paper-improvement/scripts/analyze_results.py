#!/usr/bin/env python3
"""Aggregate experiment runs and compute comparison statistics."""

from __future__ import annotations

import argparse
import csv
import json
import math
import random
from collections import defaultdict
from pathlib import Path
from typing import Any



def parse_rows(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        required = {"method", "dataset", "metric", "seed", "value"}
        missing = required - set(reader.fieldnames or [])
        if missing:
            raise ValueError(f"Missing required CSV columns: {sorted(missing)}")

        for row in reader:
            rows.append(
                {
                    "method": row["method"].strip(),
                    "dataset": row["dataset"].strip(),
                    "metric": row["metric"].strip(),
                    "seed": int(row["seed"]),
                    "value": float(row["value"]),
                    "run_id": row.get("run_id", "").strip(),
                    "compute_hours": float(row["compute_hours"]) if row.get("compute_hours") else None,
                }
            )
    return rows



def mean(values: list[float]) -> float:
    return sum(values) / len(values)



def stdev(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    mu = mean(values)
    return math.sqrt(sum((value - mu) ** 2 for value in values) / (len(values) - 1))



def percentile(sorted_values: list[float], q: float) -> float:
    if not sorted_values:
        raise ValueError("Cannot compute percentile of empty list")
    if len(sorted_values) == 1:
        return sorted_values[0]

    position = (len(sorted_values) - 1) * q
    lower = math.floor(position)
    upper = math.ceil(position)

    if lower == upper:
        return sorted_values[lower]

    weight = position - lower
    return sorted_values[lower] * (1 - weight) + sorted_values[upper] * weight



def bootstrap_ci(
    values: list[float],
    n_boot: int = 2000,
    alpha: float = 0.05,
    rng_seed: int = 0,
) -> tuple[float, float]:
    if not values:
        raise ValueError("Cannot bootstrap empty data")

    rng = random.Random(rng_seed)
    stats: list[float] = []
    n = len(values)

    for _ in range(n_boot):
        sample = [values[rng.randrange(n)] for _ in range(n)]
        stats.append(mean(sample))

    stats.sort()
    lower = percentile(stats, alpha / 2.0)
    upper = percentile(stats, 1.0 - alpha / 2.0)
    return lower, upper



def aggregate(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str, str], list[float]] = defaultdict(list)
    for row in rows:
        grouped[(row["method"], row["dataset"], row["metric"])].append(row["value"])

    output: list[dict[str, Any]] = []
    for (method, dataset, metric), values in sorted(grouped.items()):
        sorted_values = sorted(values)
        ci_low, ci_high = bootstrap_ci(values)
        output.append(
            {
                "method": method,
                "dataset": dataset,
                "metric": metric,
                "n": len(values),
                "mean": mean(values),
                "std": stdev(values),
                "median": percentile(sorted_values, 0.5),
                "min": sorted_values[0],
                "max": sorted_values[-1],
                "ci_low": ci_low,
                "ci_high": ci_high,
            }
        )
    return output



def two_sided_sign_test_pvalue(pos: int, neg: int) -> float:
    n = pos + neg
    if n == 0:
        return 1.0

    k = min(pos, neg)
    tail = 0.0
    for i in range(k + 1):
        tail += math.comb(n, i)

    p = 2.0 * tail / (2.0**n)
    return min(1.0, p)



def paired_deltas(
    rows: list[dict[str, Any]],
    baseline: str,
    lower_is_better_metrics: set[str],
) -> list[dict[str, Any]]:
    keyed: dict[tuple[str, str, str, int], float] = {}
    methods: set[str] = set()

    for row in rows:
        key = (row["dataset"], row["metric"], row["method"], row["seed"])
        keyed[key] = row["value"]
        methods.add(row["method"])

    comparisons: list[dict[str, Any]] = []

    for method in sorted(methods):
        if method == baseline:
            continue

        group_keys = {(row["dataset"], row["metric"]) for row in rows if row["method"] in {baseline, method}}
        for dataset, metric in sorted(group_keys):
            baseline_by_seed = {
                seed: val
                for (ds, mt, mth, seed), val in keyed.items()
                if ds == dataset and mt == metric and mth == baseline
            }
            method_by_seed = {
                seed: val
                for (ds, mt, mth, seed), val in keyed.items()
                if ds == dataset and mt == metric and mth == method
            }

            shared = sorted(set(baseline_by_seed) & set(method_by_seed))
            if len(shared) < 2:
                continue

            deltas = [method_by_seed[s] - baseline_by_seed[s] for s in shared]
            oriented_deltas = [(-delta if metric in lower_is_better_metrics else delta) for delta in deltas]
            ci_low, ci_high = bootstrap_ci(deltas)
            oriented_ci_low, oriented_ci_high = bootstrap_ci(oriented_deltas)
            positives = sum(1 for delta in oriented_deltas if delta > 0)
            negatives = sum(1 for delta in oriented_deltas if delta < 0)
            p_value = two_sided_sign_test_pvalue(positives, negatives)
            delta_std = stdev(oriented_deltas)
            effect_size = mean(oriented_deltas) / delta_std if delta_std > 0 else 0.0

            comparisons.append(
                {
                    "dataset": dataset,
                    "metric": metric,
                    "baseline": baseline,
                    "candidate": method,
                    "shared_seed_count": len(shared),
                    "better_direction": "lower" if metric in lower_is_better_metrics else "higher",
                    "mean_delta": mean(deltas),
                    "ci_low": ci_low,
                    "ci_high": ci_high,
                    "oriented_mean_delta": mean(oriented_deltas),
                    "oriented_ci_low": oriented_ci_low,
                    "oriented_ci_high": oriented_ci_high,
                    "improves_over_baseline": mean(oriented_deltas) > 0,
                    "wins": positives,
                    "losses": negatives,
                    "effect_size": effect_size,
                    "p_value": p_value,
                }
            )

    return comparisons



def apply_holm(comparisons: list[dict[str, Any]], alpha: float) -> None:
    ordered = sorted(enumerate(comparisons), key=lambda item: item[1]["p_value"])
    m = len(ordered)

    reject_prefix = True
    for rank, (idx, row) in enumerate(ordered, start=1):
        threshold = alpha / (m - rank + 1)
        passes = bool(row["p_value"] <= threshold) and reject_prefix
        comparisons[idx]["holm_threshold"] = threshold
        comparisons[idx]["holm_reject"] = passes
        if not passes:
            reject_prefix = False



def write_markdown(path: Path, aggregates: list[dict[str, Any]], comparisons: list[dict[str, Any]]) -> None:
    lines = [
        "# Experiment Analysis Summary",
        "",
        "## Aggregates",
        "| method | dataset | metric | n | mean | std | median | ci_low | ci_high | min | max |",
        "|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]

    for row in aggregates:
        lines.append(
            "| {method} | {dataset} | {metric} | {n} | {mean:.6f} | {std:.6f} | {median:.6f} | {ci_low:.6f} | {ci_high:.6f} | {min:.6f} | {max:.6f} |".format(
                **row
            )
        )

    lines.extend(["", "## Baseline Comparisons"])
    if not comparisons:
        lines.append("- No valid paired comparisons.")
    else:
        lines.append(
            "| dataset | metric | baseline | candidate | better_direction | shared_seeds | mean_delta | oriented_mean_delta | oriented_ci_low | oriented_ci_high | effect_size | wins | losses | p_value | holm_threshold | holm_reject | improves |"
        )
        lines.append("|---|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---|")
        for row in comparisons:
            lines.append(
                "| {dataset} | {metric} | {baseline} | {candidate} | {better_direction} | {shared_seed_count} | {mean_delta:.6f} | {oriented_mean_delta:.6f} | {oriented_ci_low:.6f} | {oriented_ci_high:.6f} | {effect_size:.6f} | {wins} | {losses} | {p_value:.6f} | {holm_threshold:.6f} | {holm_reject} | {improves_over_baseline} |".format(
                    **row
                )
            )

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")



def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs-csv", required=True)
    parser.add_argument("--baseline", default="")
    parser.add_argument("--alpha", type=float, default=0.05)
    parser.add_argument("--lower-is-better-metrics", default="", help="Comma-separated metrics")
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--output-md", required=True)
    args = parser.parse_args()

    lower_is_better_metrics = {metric.strip() for metric in args.lower_is_better_metrics.split(",") if metric.strip()}

    rows = parse_rows(Path(args.runs_csv))
    aggregates = aggregate(rows)

    comparisons: list[dict[str, Any]] = []
    if args.baseline:
        comparisons = paired_deltas(rows, args.baseline, lower_is_better_metrics)
        if comparisons:
            apply_holm(comparisons, args.alpha)

    payload = {
        "aggregates": aggregates,
        "comparisons": comparisons,
        "alpha": args.alpha,
        "lower_is_better_metrics": sorted(lower_is_better_metrics),
    }

    output_json = Path(args.output_json)
    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(payload, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")

    write_markdown(Path(args.output_md), aggregates, comparisons)

    print(f"Wrote {args.output_json}")
    print(f"Wrote {args.output_md}")


if __name__ == "__main__":
    main()
