#!/usr/bin/env python3
"""Turn manuscript quality-gate issues into a prioritized revision plan."""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SEVERITY_ORDER = {"blocker": 0, "major": 1, "moderate": 2, "info": 3}
SEVERITY_TO_IMPACT = {
    "blocker": "high",
    "major": "high",
    "moderate": "medium",
    "info": "low",
}
SEVERITY_TO_EFFORT = {
    "blocker": "l",
    "major": "m",
    "moderate": "s",
    "info": "s",
}



def load_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"Expected JSON object in {path}")
    return data



def choose_owner(issue: dict[str, Any], paper_spec: dict[str, Any] | None) -> str:
    category = str(issue.get("category", ""))
    empirical = bool((paper_spec or {}).get("extraction", {}).get("datasets") or (paper_spec or {}).get("extraction", {}).get("metrics"))
    if category in {"empirical_rigor", "reproducibility"} and empirical:
        return "author+experiment"
    if category == "ethics_reporting":
        return "author"
    return "author"



def title_from_issue(issue: dict[str, Any]) -> str:
    code = str(issue.get("code", "")).replace("_", " ").strip().title()
    if code:
        return code
    return str(issue.get("message", "Revision item")).strip()[:80]



def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--quality-gate", required=True)
    parser.add_argument("--paper-spec", default="")
    parser.add_argument("--max-items", type=int, default=12)
    parser.add_argument("--output-jsonl", required=True)
    parser.add_argument("--output-md", required=True)
    args = parser.parse_args()

    gate = load_json(Path(args.quality_gate))
    paper_spec = load_json(Path(args.paper_spec)) if args.paper_spec else None
    issues = gate.get("issues", [])
    if not isinstance(issues, list):
        raise ValueError("quality gate must contain an issues list")

    sorted_issues = sorted(
        [issue for issue in issues if isinstance(issue, dict)],
        key=lambda item: (SEVERITY_ORDER.get(str(item.get("severity", "info")), 3), str(item.get("category", "")), str(item.get("code", ""))),
    )

    plan_items: list[dict[str, Any]] = []
    for idx, issue in enumerate(sorted_issues[: args.max_items], start=1):
        severity = str(issue.get("severity", "info"))
        category = str(issue.get("category", ""))
        plan_items.append(
            {
                "id": f"R{idx:03d}",
                "severity": severity,
                "category": category,
                "title": title_from_issue(issue),
                "rationale": str(issue.get("message", "")).strip(),
                "recommended_action": str(issue.get("recommended_action", "")).strip(),
                "effort": SEVERITY_TO_EFFORT.get(severity, "s"),
                "expected_impact": SEVERITY_TO_IMPACT.get(severity, "low"),
                "owner": choose_owner(issue, paper_spec),
            }
        )

    output_jsonl = Path(args.output_jsonl)
    output_jsonl.parent.mkdir(parents=True, exist_ok=True)
    with output_jsonl.open("w", encoding="utf-8") as handle:
        for item in plan_items:
            handle.write(json.dumps(item, ensure_ascii=True) + "\n")

    lines = [
        "# Revision Plan",
        "",
        f"- Generated at: {datetime.now(timezone.utc).isoformat()}",
        f"- Source readiness: {gate.get('readiness', '')}",
        "",
        "| id | severity | category | title | effort | impact | owner | recommended_action |",
        "|---|---|---|---|---|---|---|---|",
    ]
    for item in plan_items:
        lines.append(
            "| {id} | {severity} | {category} | {title} | {effort} | {impact} | {owner} | {action} |".format(
                id=item["id"],
                severity=item["severity"],
                category=item["category"],
                title=item["title"].replace("|", " "),
                effort=item["effort"],
                impact=item["expected_impact"],
                owner=item["owner"],
                action=item["recommended_action"].replace("|", " "),
            )
        )

    output_md = Path(args.output_md)
    output_md.parent.mkdir(parents=True, exist_ok=True)
    output_md.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"Wrote {output_jsonl}")
    print(f"Wrote {output_md}")


if __name__ == "__main__":
    main()
